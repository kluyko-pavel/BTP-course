sap.ui.define([
  "sap/ui/core/mvc/Controller"
], (BaseController) => {
  "use strict";

  return BaseController.extend("nsl.incidentsfreestyle.controller.App", {
      onInit() {
      }
  });
});